package com.example.kanban_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
